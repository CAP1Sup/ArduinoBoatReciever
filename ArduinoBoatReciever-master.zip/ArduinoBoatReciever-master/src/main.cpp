
#include <Arduino.h>
#include <PPM.hpp>
//#include <iBUStelemetry.h>
#include <Math.cpp>
#include <Ramp.cpp>

int throttle_pin = 12;
int ch1_pin = A0;
int ch3_pin = A1;
int ch5_pin = A2;
int ch6_pin = A3;

bool Serial_output = true;

int threshold = 15;
/*
const int numReadings = 3;
 
int readings[numReadings];      // the readings from the analog input
int readIndex = 0;              // the index of the current reading
int total = 0;                  // the running total
int average = 0;                // the average
*/
float ch1 = 0; //Steering
float ch3 = 0; //Throttle
float ch5 = 0; //3-way switch (for ramping type)
float ch6 = 0; //Dial (for ramp speed)

Math ch1_math;
Math ch3_math;
Math ch5_math;
Math ch6_math;

rampFloat L_motor;
rampFloat R_motor;

//PPM reciever;
//iBUStelemetry telemetry(iBUS_pin);

void applyThrottle() {
  
  
  /*
    // subtract the last reading:
  total = total - readings[readIndex];
  // read from the sensor:
  readings[readIndex] = map(pulseIn(2, HIGH), 0, 2000, 0, 510) - 249;
  // add the reading to the total:
  total = total + readings[readIndex];
  // advance to the next position in the array:
  readIndex = readIndex + 1;
 
  // if we're at the end of the array...
  if (readIndex >= numReadings) {
    // ...wrap around to the beginning:
    readIndex = 0;
  }
  */
  
  ch1 = ( ch1_math.average ( map ( pulseIn ( ch1_pin, HIGH ), 0, 2000, 0, 510 ) - 249 ) ) - 1;
  
  ch5 = ( ch1_math.average ( map ( pulseIn ( ch5_pin, HIGH ), 0, 2000, 0, 510 ) - 249 ) ) - 1; // 1: 126 2: 189-190 3: 253-254

  if (ch5 < 180) { //1st position

  }

  else if (ch5 == 189 || ch5 == 190) { //2nd position

  }

  else { //3rd position

  }

  if (Serial_output) {
    //Serial.print(ch1);
    //Serial.print(", ");
    //Serial.print(ch5);
    //Serial.println();
  }

}








/*
void applyThrottle() {

  if (reciever.getValue(7) == 0 ) {

    analogWrite( throttle_pin, (reciever.getValue(1)*.25) ); //25% power

  }

  else if (reciever.getValue(7) < 0) {

    int variableThrottle = (reciever.getValue(1) * ( map(reciever.getValue(8), 0, 255, 0, 1) ));
    analogWrite( throttle_pin, variableThrottle );
    
  }

  else {

    analogWrite( throttle_pin, reciever.getValue(1) );

  }

}
*/


/*
void writeSensorData() {
  //Do some stuff to figure out telemetry
  telemetry.setSensorMeasurement(1, 1.2);

}
*/

void setup() {
  // put your setup code here, to run once:
  //reciever.begin(2,1);
  //telemetry.begin(115200);
  //telemetry.addSensor(0);
  if (Serial_output) {
    Serial.begin(115200);
  }
  /*
  //Initialize averaging stuff
  for (int thisReading = 0; thisReading < numReadings; thisReading++) {
    readings[thisReading] = 0;
  }
  */
  ch1 = map(pulseIn(2, HIGH), 0, 2000, 0, 510) - 250;
  math.initializeAverages(3);
}

void loop() {
  // put your main code here, to run repeatedly:
  applyThrottle();
}

