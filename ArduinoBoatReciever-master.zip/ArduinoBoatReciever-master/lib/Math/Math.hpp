class Math {
public:
    void initializeAverages(int iterations);
    double average(double currentValue);
};